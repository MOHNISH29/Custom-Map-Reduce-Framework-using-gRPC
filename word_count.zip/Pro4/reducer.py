
import grpc
from concurrent import futures
import grpc
import concurrent.futures as futures
import master_pb2_grpc
import master_pb2
import mapper_pb2_grpc
import mapper_pb2
import partition_pb2
import partition_pb2_grpc
import reduce_pb2
import reduce_pb2_grpc
import random
from collections import defaultdict



class Reducer(reduce_pb2_grpc.ReducerServicer):
    def __init__(self):
        self.word_table = {}
    
    def KeyValuePairsFromPart(self, request, context):
        for count in request.key.split():
            if count in self.word_table:
                self.word_table[count] += 1
            else:
                self.word_table[count] = 1

        print(self.word_table)

        return reduce_pb2.KeyValuePairsFromPartResponse()


def reduce():
    print("Reducer Created...")
    #STARTING A REDUCER ON SOME PORT AND CONNECTING IT WITH MASTER TO SHARE PORT NUMBER WITH IT
    master_channel = grpc.insecure_channel('localhost:50051')
    master_stub = master_pb2_grpc.MasterStub(master_channel)
    port_random = random.randint(50052, 65535)
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))

    # Construct the server address string using string concatenation
    server_address = f"[::]:{port_random}"
    server.add_insecure_port(server_address)
    server.start()

    request = master_pb2.ReducerInfoRequest(port=port_random)
    response = master_stub.RegisterReducer(request)


    reduce_pb2_grpc.add_ReducerServicer_to_server(Reducer(), server)
    server.wait_for_termination()


if __name__ == '__main__':
    reduce()