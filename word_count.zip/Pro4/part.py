import grpc
from concurrent import futures
import grpc
import concurrent.futures as futures
import master_pb2_grpc
import master_pb2
import mapper_pb2_grpc
import mapper_pb2
import partition_pb2
import partition_pb2_grpc
import reduce_pb2
import reduce_pb2_grpc
import random
from collections import defaultdict
import hashlib


class Partition(partition_pb2_grpc.PartitionServicer):
    def __init__(self):
        #self.KeyValuePairs = defaultdict(list)
        self.Key = []
        self.Value = []

    def StoreKeyValuePair(self , request , context):
        # self.KeyValuePairs[request.key].append(request.value)
        # print(self.KeyValuePairs)
        self.Key.append(request.key)
        self.Value.append(request.value)
        return partition_pb2.KeyValuePairResponse()
    
    def SignalFromMaster(self, request , context):
        print("Signal received")
        master_channel = grpc.insecure_channel('localhost:50051')
        master_stub = master_pb2_grpc.MasterStub(master_channel)
        request = master_pb2.getReducerListRequest()
        response = master_stub.SendReducerPortInfo(request)

        my_reducer_list = response.reducer_list

        for i in range(len(self.Key)):
            reducer_id = int(hashlib.sha256(self.Key[i].encode('utf-8')).hexdigest(), 16) % len(my_reducer_list)
            reducer_port = my_reducer_list[reducer_id]
            server_here = 'localhost:'+str(reducer_port)
            reducer_channel = grpc.insecure_channel(server_here)
            reducer_stub = reduce_pb2_grpc.ReducerStub(reducer_channel)

            request = reduce_pb2.KeyValuePairsFromPartRequest(key = self.Key[i] , value = int(self.Value[i]) )
            response = reducer_stub.KeyValuePairsFromPart(request)

        return partition_pb2.SignalFromMasterResponse()


def partition():
    print("Partition Created...")
    #STARTING A PARTITION ON SOME PORT AND CONNECTING IT WITH MASTER TO SHARE PORT NUMBER WITH IT
    master_channel = grpc.insecure_channel('localhost:50051')
    master_stub = master_pb2_grpc.MasterStub(master_channel)
    port_random = random.randint(50052, 65535)

    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    #mapper_pb2_grpc.add_MapperServicer_to_server(Mapper(), server)
    # Construct the server address string using string concatenation
    server_address = f"[::]:{port_random}"
    server.add_insecure_port(server_address)
    server.start()

    request = master_pb2.PartitionInfoRequest(port=port_random)
    response = master_stub.RegisterPartition(request)

    partition_pb2_grpc.add_PartitionServicer_to_server(Partition(), server)
    server.wait_for_termination()


if __name__ == '__main__':
    partition()