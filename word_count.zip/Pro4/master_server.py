import grpc
from concurrent import futures
import grpc
import concurrent.futures as futures
import master_pb2_grpc
import master_pb2
import partition_pb2
import partition_pb2_grpc

class Master(master_pb2_grpc.MasterServicer):
    def __init__(self , word_list1 , word_list2 , word_list3,counter,signal_count):
        self.mapper_list = []
        self.partition_list = []
        self.reducer_list = []
        self.word_list1 = word_list1
        self.word_list2 = word_list2
        self.word_list3 = word_list3
        self.counter = counter
        self.signal_count = signal_count
     
    def RegisterMapper(self,request,context):
        self.mapper_list.append(request.port)
        print("Mapper registering with port number:")
        print(request)
        return master_pb2.MapperInfoResponse()
    
    def RegisterPartition(self, request, context):
        self.partition_list.append(request.port)
        print("Partition registering with port number:")
        print(request)
        return master_pb2.PartitionInfoResponse()
    
    def RegisterReducer(self , request , context):
        self.reducer_list.append(request.port)
        print("Reducer registering with port number:")
        print(request)
        return master_pb2.ReducerInfoResponse()
    
    def SendPartitionPortInfo(self, request, context):
        return master_pb2.getPartitionListResponse(part_list = self.partition_list)
    
    def SendReducerPortInfo(self, request, context):
        return master_pb2.getReducerListResponse(reducer_list = self.reducer_list)
    
    def SendData(self, request, context):
        data2send = []
        self.counter = self.counter + 1
        if(str(self.counter)=="1"):
            data2send = self.word_list1
        elif(str(self.counter)=="2"):
            data2send = self.word_list2
        elif(str(self.counter)=="3"):
            data2send = self.word_list3
        else:
            data2send = []
            
        return master_pb2.DataResponse(data=data2send)
    
    def SignalFromMapper(self, request, context):
        self.signal_count = self.signal_count+1
        if self.signal_count==3:
            self.signal_count = 0
            for port_num in self.partition_list:
                server_here = 'localhost:'+str(port_num)
                partition_channel = grpc.insecure_channel(server_here)
                partition_stub = partition_pb2_grpc.PartitionStub(partition_channel)
                request = partition_pb2.SignalFromMasterRequest()
                response = partition_stub.SignalFromMaster(request)

        return master_pb2.SignalResponse()

        
#STORING FILE DATA IN THREE DIFFERENT VARAIBLES
word_list1 = []
word_list2 = []
word_list3 = []
with open('input1.txt','r') as file:
    content = file.read()
    word_list = content.split()
    for i in range(len(word_list)):
        word_list[i] = word_list[i].lower()
    word_list1 = list((word_list))
    print(word_list)
with open('input2.txt','r') as file:
    content = file.read()
    word_list = content.split()
    for i in range(len(word_list)):
        word_list[i] = word_list[i].lower()
    word_list2 = list((word_list))
    print(word_list)
with open('input3.txt','r') as file:
    content = file.read()
    word_list = content.split()
    for i in range(len(word_list)):
        word_list[i] = word_list[i].lower()
    word_list3 = list((word_list))
    print(word_list)

#creating stub for master and starting it on port 50051
server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
master_pb2_grpc.add_MasterServicer_to_server(Master(word_list1,word_list2,word_list3,0,0), server)
server.add_insecure_port('[::]:50051')
server.start()
print("Master Server started..")



server.wait_for_termination()