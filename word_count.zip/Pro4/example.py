import hashlib
# key = "blablablalblalballbafndjfnsweufuenfwufuen"
# key1 = "blablablalblalballbafndjfnsweufuenfwufuen"
# num_partitions=4
# partition_id = int(hashlib.sha256(key.encode('utf-8')).hexdigest(), 16) % num_partitions
# partition_id1 = int(hashlib.sha256(key1.encode('utf-8')).hexdigest(), 16) % num_partitions
# print(partition_id)
# print(partition_id1)
from collections import defaultdict
my_dict = defaultdict(list)
my_dict['mohnish'].append(2)
my_dict['mohnish'].append(4)
my_dict["kushal"].append("3")
print(my_dict)