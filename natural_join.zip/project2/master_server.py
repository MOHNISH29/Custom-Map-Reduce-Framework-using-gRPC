import grpc
from concurrent import futures
import grpc
import concurrent.futures as futures
import master_pb2_grpc
import master_pb2
import partition_pb2
import partition_pb2_grpc

class Master(master_pb2_grpc.MasterServicer):
    def __init__(self , word_list1 , word_list2 , word_list3,word_list4,counter,signal_count):
        self.mapper_list = []
        self.partition_list = []
        self.reducer_list = []
        self.word_list1 = word_list1
        self.word_list2 = word_list2
        self.word_list3 = word_list3
        self.word_list4 = word_list4
        self.counter = counter
        self.signal_count = signal_count
    

    def RegisterMapper(self,request,context):
        self.mapper_list.append(request.port)
        print("Mapper registering with port number:")
        print(request)
        return master_pb2.MapperInfoResponse()
    
    def RegisterPartition(self, request, context):
        self.partition_list.append(request.port)
        print("Partition registering with port number:")
        print(request)
        return master_pb2.PartitionInfoResponse()
    
    def RegisterReducer(self , request , context):
        self.reducer_list.append(request.port)
        print("Reducer registering with port number:")
        print(request)
        return master_pb2.ReducerInfoResponse()
    
    def SendPartitionPortInfo(self, request, context):
        return master_pb2.getPartitionListResponse(part_list = self.partition_list)
    
    def SendReducerPortInfo(self, request, context):
        return master_pb2.getReducerListResponse(reducer_list = self.reducer_list)
    
    def SendData(self, request, context):
        data2send1 = []
        data2send2 = []
        self.counter = self.counter + 1
        if(str(self.counter)=="1"):
            data2send1 = [master_pb2.Tuple(field1 = e1 , field2 = e2) for e1,e2 in self.word_list1]
            data2send2 = [master_pb2.Tuple(field1 = e1 , field2 = e2) for e1,e2 in self.word_list2]
        
        else:
            data2send1 = [master_pb2.Tuple(field1 = e1 , field2 = e2) for e1,e2 in self.word_list3]
            data2send2 = [master_pb2.Tuple(field1 = e1 , field2 = e2) for e1,e2 in self.word_list4]
        
        return master_pb2.DataResponse(data1=data2send1 , data2=data2send2, file_number = str(self.counter))
    
    def SignalFromMapper(self, request, context):
        self.signal_count = self.signal_count+1
        if self.signal_count==2:
            self.signal_count = 0
            for port_num in self.partition_list:
                server_here = 'localhost:'+str(port_num)
                partition_channel = grpc.insecure_channel(server_here)
                partition_stub = partition_pb2_grpc.PartitionStub(partition_channel)
                request = partition_pb2.SignalFromMasterRequest()
                response = partition_stub.SignalFromMaster(request)

        return master_pb2.SignalResponse()

        
#STORING FILE DATA IN THREE DIFFERENT VARAIBLES
# word_list1 = []
# word_list2 = []
# word_list3 = []
# with open('input1.txt','r') as file:
#     content = file.read()
#     word_list = content.split()
#     for i in range(len(word_list)):
#         word_list[i] = word_list[i].lower()
#     word_list1 = list(set(word_list))
#     print(word_list)
# with open('input2.txt','r') as file:
#     content = file.read()
#     word_list = content.split()
#     for i in range(len(word_list)):
#         word_list[i] = word_list[i].lower()
#     word_list2 = list(set(word_list))
#     print(word_list)
# with open('input3.txt','r') as file:
#     content = file.read()
#     word_list = content.split()
#     for i in range(len(word_list)):
#         word_list[i] = word_list[i].lower()
#     word_list3 = list(set(word_list))
#     print(word_list)
table1 = []
table2 = []
table3 = []
table4 = []

with open('input1_table1.txt','r') as file:
    for line in file:
        fields = line.strip().split(",")
        record = (fields[0],fields[1])
        table1.append(record)
    col1 = table1.pop(0)
# print(k)
    
with open('input1_table2.txt','r') as file:
    for line in file:
        fields = line.strip().split(",")
        record = (fields[0],fields[1])
        table2.append(record)
    col2 = table2.pop(0)
# print(table2)

with open('input2_table1.txt','r') as file:
    for line in file:
        fields = line.strip().split(",")
        record = (fields[0],fields[1])
        table3.append(record)
    col3 = table3.pop(0)
# print(table3)

with open('input2_table2.txt','r') as file:
    for line in file:
        fields = line.strip().split(",")
        record = (fields[0],fields[1])
        table4.append(record)
    col4 = table4.pop(0)

print(table1)
#creating stub for master and starting it on port 50051
server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
master_pb2_grpc.add_MasterServicer_to_server(Master(table1,table2,table3,table4,0,0), server)
server.add_insecure_port('[::]:50051')
server.start()
print("Master Server started..")



server.wait_for_termination()