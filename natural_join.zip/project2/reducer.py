
import grpc
from concurrent import futures
import grpc
import concurrent.futures as futures
import master_pb2_grpc
import master_pb2
import mapper_pb2_grpc
import mapper_pb2
import partition_pb2
import partition_pb2_grpc
import reduce_pb2
import reduce_pb2_grpc
import random
from collections import defaultdict



class Reducer(reduce_pb2_grpc.ReducerServicer):
    def __init__(self):
        self.KeyValuePairs = defaultdict(list)
        self.output_list = []
        self.final_tuple = []
    
    def KeyValuePairsFromPart(self, request, context):
        tup_list= []
        for v in request.value:
            for t in v.tuple:
                tup = (request.key,t.field1,t.field2)
                tup_list.append(tup)

        # print(tup_list)
        l=tup_list
        for i in range(len(l)-1):
            for j in range(i+1,len(l)):
                if(l[i][1]!=l[j][1]):
                    if(l[i][1]=="T1"):
                        t = (l[i][0],l[i][2],l[j][2])
                    else:
                        t = (l[i][0],l[j][2],l[i][2])
                    self.final_tuple.append(t)
        print(self.final_tuple)
        # col = ('Name','Age','Role')
        # self.final_tuple.insert(0,col)
        


        return reduce_pb2.KeyValuePairsFromPartResponse()


def reduce():
    print("Reducer Created...")
    #STARTING A REDUCER ON SOME PORT AND CONNECTING IT WITH MASTER TO SHARE PORT NUMBER WITH IT
    master_channel = grpc.insecure_channel('localhost:50051')
    master_stub = master_pb2_grpc.MasterStub(master_channel)
    port_random = random.randint(50052, 65535)
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))

    # Construct the server address string using string concatenation
    server_address = f"[::]:{port_random}"
    server.add_insecure_port(server_address)
    server.start()

    request = master_pb2.ReducerInfoRequest(port=port_random)
    response = master_stub.RegisterReducer(request)


    reduce_pb2_grpc.add_ReducerServicer_to_server(Reducer(), server)
    server.wait_for_termination()


if __name__ == '__main__':
    reduce()