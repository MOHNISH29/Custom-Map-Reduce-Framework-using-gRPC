
import grpc
from concurrent import futures
import grpc
import concurrent.futures as futures
import master_pb2_grpc
import master_pb2
import mapper_pb2_grpc
import mapper_pb2
import random
import hashlib
import partition_pb2
import partition_pb2_grpc


class Mapper(mapper_pb2_grpc.MapperServicer):
    def __init__(self  , file_index , hash_table):
        
        self.file_index = file_index
        self.hash_table = hash_table

def serve():
    
    print("Mapper created..")
    #STARTING A MAPPER ON SOME PORT AND CONNECTING IT WITH MASTER TO SHARE PORT NUMBER WITH IT
    master_channel = grpc.insecure_channel('localhost:50051')
    master_stub = master_pb2_grpc.MasterStub(master_channel)
    port_random = random.randint(50052, 65535)
    
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    #mapper_pb2_grpc.add_MapperServicer_to_server(Mapper(), server)
    # Construct the server address string using string concatenation
    server_address = f"[::]:{port_random}"
    server.add_insecure_port(server_address)
    server.start() 

    request = master_pb2.MapperInfoRequest(port=port_random)
    response = master_stub.RegisterMapper(request)

    #ASK FOR DATA FROM MASTER USING COUNTER AS THE INDEX AND STORING DATA AS KEY VALUE PAIR IN hash_table
    result1 = {}
    request = master_pb2.DataRequest()
    response = master_stub.SendData(request)
    #print(response)
    # print(response.data)
    # for word in response.data:
    #     hash_table[word] = response.file_number
    # print(response.file_number)
    # list_of_words = response.data
    table1 = response.data1
    table2 = response.data2
    print(table1)
    for row1 in table1:
       
    # Extract the value of the common column in table 1
        common_value = row1.field1

    # Initialize a flag to track whether there's a match
        match_found = False

    # Iterate over the rows in table 2
        for row2 in table2:
        # Extract the value of the common column in table 2
            if row2.field1 == common_value:
            # If there's a match, add the row to the result1 dictionary
                if common_value not in result1:
                    result1[common_value] = [('T1', row1.field2), ('T2', row2.field2)]
                else:
                    result1[common_value].append(('T2', row2.field2))
                match_found = True
                break

    # If no match was found and the key is not already in the dictionary, add the row to the result1 dictionary
        if not match_found and common_value not in result1:
            result1[common_value] = [('T1', row1.field2)]

# Iterate over the rows in table 2 to add any non-matching keys to the result1 dictionary
    for row2 in table2:
        common_value = row2.field1
        if common_value not in result1:
            result1[common_value] = [('T2', row2.field2)]
    print(result1)
    mapper_pb2_grpc.add_MapperServicer_to_server(Mapper( response.file_number , result1), server)

    #ASK FOR LIST OF PARTITIONS AVAILABLE TO SEND DATA TO
    request = master_pb2.getPartitionListRequest()
    response = master_stub.SendPartitionPortInfo(request)
    print(response.part_list)
    part_list = response.part_list

    #FINDING HASH OF A WORD AND ASSIGNING A UNIQUE PARTITION TO IT
    num_partitions = len(part_list)
    # print(result1)
    for key ,value in result1.items():
        partition_id = int(hashlib.sha256(key.encode('utf-8')).hexdigest(), 16) % num_partitions
        partition_port = part_list[partition_id]
        server_here = 'localhost:'+str(partition_port)
        partition_channel = grpc.insecure_channel(server_here)
        partition_stub = partition_pb2_grpc.PartitionStub(partition_channel)
        # print(len(value))
        value=[partition_pb2.Tuple(field1 = e1 , field2 = e2) for e1,e2 in value]
        request = partition_pb2.KeyValuePairRequest(key = key , value = value)
        response = partition_stub.StoreKeyValuePair(request)
    
    request = master_pb2.SignalRequest()
    response = master_stub.SignalFromMapper(request)

    
    server.wait_for_termination()
    
if __name__ == '__main__':
    serve()