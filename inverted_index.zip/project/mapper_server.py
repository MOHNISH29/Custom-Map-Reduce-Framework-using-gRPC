
import grpc
from concurrent import futures
import grpc
import concurrent.futures as futures
import master_pb2_grpc
import master_pb2
import mapper_pb2_grpc
import mapper_pb2
import random
import hashlib
import partition_pb2
import partition_pb2_grpc


class Mapper(mapper_pb2_grpc.MapperServicer):
    def __init__(self , data_values , file_index , hash_table):
        self.data_values = data_values
        self.file_index = file_index
        self.hash_table = hash_table

def serve():
    
    print("Mapper created..")
    #STARTING A MAPPER ON SOME PORT AND CONNECTING IT WITH MASTER TO SHARE PORT NUMBER WITH IT
    master_channel = grpc.insecure_channel('localhost:50051')
    master_stub = master_pb2_grpc.MasterStub(master_channel)
    port_random = random.randint(50052, 65535)
    
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    #mapper_pb2_grpc.add_MapperServicer_to_server(Mapper(), server)
    # Construct the server address string using string concatenation
    server_address = f"[::]:{port_random}"
    server.add_insecure_port(server_address)
    server.start() 

    request = master_pb2.MapperInfoRequest(port=port_random)
    response = master_stub.RegisterMapper(request)

    #ASK FOR DATA FROM MASTER USING COUNTER AS THE INDEX AND STORING DATA AS KEY VALUE PAIR IN hash_table
    hash_table = {}
    request = master_pb2.DataRequest()
    response = master_stub.SendData(request)
    print(response.data)
    for word in response.data:
        hash_table[word] = response.file_number
    print(response.file_number)
    list_of_words = response.data
    mapper_pb2_grpc.add_MapperServicer_to_server(Mapper(response.data , response.file_number , hash_table), server)

    #ASK FOR LIST OF PARTITIONS AVAILABLE TO SEND DATA TO
    request = master_pb2.getPartitionListRequest()
    response = master_stub.SendPartitionPortInfo(request)
    print(response.part_list)
    part_list = response.part_list

    #FINDING HASH OF A WORD AND ASSIGNING A UNIQUE PARTITION TO IT
    #num_partitions=3
    num_partitions = len(part_list)
    for word in list_of_words:
        partition_id = int(hashlib.sha256(word.encode('utf-8')).hexdigest(), 16) % num_partitions
        partition_port = part_list[partition_id]
        server_here = 'localhost:'+str(partition_port)
        partition_channel = grpc.insecure_channel(server_here)
        partition_stub = partition_pb2_grpc.PartitionStub(partition_channel)
        request = partition_pb2.KeyValuePairRequest(key = word , value = hash_table[word])
        response = partition_stub.StoreKeyValuePair(request)
    
    request = master_pb2.SignalRequest()
    response = master_stub.SignalFromMapper(request)

    
    server.wait_for_termination()
    
if __name__ == '__main__':
    serve()